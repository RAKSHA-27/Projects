
def duckduckgo_search(query):
    import requests
    from bs4 import BeautifulSoup
    url = f"https://duckduckgo.com/html/?q={query}"
    headers = {'User-Agent': 'Mozilla/5.0'}
    response = requests.get(url, headers=headers)
    soup = BeautifulSoup(response.text, 'html.parser')
    search_results = soup.find_all('a', class_='result__a')
    return search_results
def search():
  import streamlit as st
  
  query = st.text_input('')

  if st.button('Search'):
      if query:
          results = duckduckgo_search(query)
          st.write(f'Search Results for "{query}":')
          for i, result in enumerate(results, 1):
              st.write(f"{i}. [{result.text}]({result['href']})")
      else:
          st.warning('Please enter a search query.')
